import React from "react";

function FAQ(){
    return (
        <h1>Preguntas</h1>
    );
}
export default FAQ;