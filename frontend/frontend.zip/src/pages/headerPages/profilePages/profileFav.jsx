// Ejemplo mínimo correcto
import React from "react";

function ProfileFav() {
  return <div>Favoritos</div>;
}

export default ProfileFav;   // << clave: export default
