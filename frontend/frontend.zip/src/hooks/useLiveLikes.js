import { useEffect, useState, useCallback } from "react";
import { socket } from "../utils/socket";
import {
  getMyLikedTagIds,
  getMyLikedRoadmapIds,
  likeTag, unlikeTag,
  likeRoadmap, unlikeRoadmap
} from "../services/likes";

export default function useLiveLikes({ autoLoad = true } = {}) {
  const [likedTags, setLikedTags] = useState(() => new Set());
  const [likedRoadmaps, setLikedRoadmaps] = useState(() => new Set());
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [t, r] = await Promise.all([getMyLikedTagIds(), getMyLikedRoadmapIds()]);
      setLikedTags(t); setLikedRoadmaps(r);
    } finally { setLoading(false); }
  }, []);

  // carga inicial
  useEffect(() => { if (autoLoad) load(); }, [autoLoad, load]);

  // escucha eventos del servidor y recarga
  useEffect(() => {
    const onLikes = () => load();
    socket.on("likes:updated", onLikes);
    return () => socket.off("likes:updated", onLikes);
  }, [load]);

  // helpers locales que además emiten al server via REST, y luego recargan
  const likeTagAction = async (ref) => { await likeTag(ref); await load(); };
  const unlikeTagAction = async (ref) => { await unlikeTag(ref); await load(); };
  const likeRoadmapAction = async (id) => { await likeRoadmap(id); await load(); };
  const unlikeRoadmapAction = async (id) => { await unlikeRoadmap(id); await load(); };

  return {
    likedTags, likedRoadmaps, loading,
    reloadLikes: load,
    likeTag: likeTagAction,
    unlikeTag: unlikeTagAction,
    likeRoadmap: likeRoadmapAction,
    unlikeRoadmap: unlikeRoadmapAction,
  };
}
